# Accessibility approach (WCAG 2.1 AA)

CivicVoice is built accessibility-first because it is a public-facing civic
survey tool: every respondent, including people using a screen reader,
keyboard-only navigation, voice control, or a low-vision display setting,
needs to be able to complete the survey independently.

## What's implemented in this sample

| WCAG 2.1 success criterion | Implementation |
|---|---|
| 1.1.1 Non-text content | Icons (e.g. the drag handle) are `aria-hidden` and paired with visible text labels. |
| 1.3.1 Info and relationships | Real `<fieldset>`/`<legend>` for every question; `<table>` with `<th scope="col">` for grids; form controls always paired with `<label for>`. |
| 1.4.3 Contrast (minimum) | Palette in `_variables.scss` is tuned to ≥ 4.5:1 for body text against `$color-surface`; verified with axe-core / WAVE as part of CI. |
| 2.1.1 Keyboard | No mouse-only interactions. The Build-Survey reorder control has a typed "sort order" field as a full keyboard alternative to drag-and-drop. |
| 2.4.1 Bypass blocks | `.skip-link` at the top of `_Layout.cshtml` jumps to `#main-content`. |
| 2.4.7 Focus visible | A single `focus-visible-ring` mixin (`_mixins.scss`) is applied consistently — never `outline: none` without a documented replacement. |
| 3.3.1 / 3.3.3 Error identification & suggestion | Error-summary pattern (`.error-summary`, `role="alert"`, `tabindex="-1"`) is shown both client-side (`survey-validation.js`) and after a server round-trip (`Take.cshtml`), with each message linked to its field. |
| 3.3.2 Labels or instructions | Every field has a visible label; optional fields are marked "(optional)" rather than requiring everything by default. |
| 4.1.2 Name, role, value | Native semantic elements (`radio`, `checkbox`, `select`) are used instead of custom `div`-based widgets, so assistive tech gets correct roles/states for free. |
| 4.1.3 Status messages | `#live-region` (`aria-live="polite"`) announces validation and save outcomes without moving focus unexpectedly. |

## Testing this project

- **Automated:** `axe-core` CLI step in `azure-pipelines.yml` runs against the
  rendered public survey and the admin builder page on every build.
- **Manual keyboard pass:** Tab through `/s/{token}` end to end — every
  control must be reachable and show a visible focus ring, and the Likert /
  rating "button" options must be operable with Space/Enter since they are
  native radio inputs styled as cards.
- **Screen reader spot-check:** NVDA (Windows) or VoiceOver (macOS) reading
  through the error summary after an invalid submission should announce the
  error count and let the user jump directly to each invalid field.
- **Reduced motion:** `prefers-reduced-motion: reduce` disables the smooth
  scroll and button transitions (`respect-reduced-motion` mixin).

## Where a real engagement would go further

- Formal conformance testing against the DHS Trusted Tester process / IAAP
  WAS methodology, with a documented VPAT.
- Color-contrast and target-size review with a design-system team rather
  than a single developer's token choices.
- User testing with actual assistive-technology users, not just automated
  tooling — axe-core and similar tools catch roughly a third of real
  accessibility issues on their own.
