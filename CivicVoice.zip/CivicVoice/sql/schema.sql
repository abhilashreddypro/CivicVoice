-- =============================================================================
-- CivicVoice database schema (SQL Server / T-SQL)
-- =============================================================================
CREATE DATABASE CivicVoice;
GO
USE CivicVoice;
GO

CREATE TABLE dbo.Surveys (
    SurveyId        INT IDENTITY(1,1) PRIMARY KEY,
    Name            NVARCHAR(200)   NOT NULL,
    PublicToken     NVARCHAR(32)    NOT NULL,
    IntroParagraph  NVARCHAR(MAX)   NULL,
    IsPublished     BIT             NOT NULL DEFAULT 0,
    CreateUser      NVARCHAR(100)   NOT NULL,
    CreateDt        DATETIME2       NOT NULL DEFAULT SYSUTCDATETIME(),
    UpdateUser      NVARCHAR(100)   NULL,
    UpdateDt        DATETIME2       NULL,
    CONSTRAINT UQ_Surveys_PublicToken UNIQUE (PublicToken)
);
GO

CREATE TABLE dbo.SurveyQuestions (
    SurveyQuestionId INT IDENTITY(1,1) PRIMARY KEY,
    SurveyId         INT NOT NULL REFERENCES dbo.Surveys(SurveyId),
    QuestionText     NVARCHAR(1000) NOT NULL,
    DisplayTypeId    INT NOT NULL,         -- FK -> DisplayTypes lookup (omitted for brevity)
    SortOrder        INT NOT NULL DEFAULT 0,
    IsRequired       BIT NOT NULL DEFAULT 1,
    OptionsJson      NVARCHAR(MAX) NULL,
    Deleted          BIT NOT NULL DEFAULT 0,
    CreateUser       NVARCHAR(100) NOT NULL,
    CreateDt         DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME(),
    UpdateUser       NVARCHAR(100) NULL,
    UpdateDt         DATETIME2 NULL
);
GO

CREATE TABLE dbo.SurveyResponses (
    SurveyResponseId INT IDENTITY(1,1) PRIMARY KEY,
    SurveyId         INT NOT NULL REFERENCES dbo.Surveys(SurveyId),
    Email            NVARCHAR(256) NULL,
    SubmittedDt      DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME()
);
GO

CREATE TABLE dbo.SurveyAnswers (
    SurveyAnswerId    INT IDENTITY(1,1) PRIMARY KEY,
    SurveyResponseId  INT NOT NULL REFERENCES dbo.SurveyResponses(SurveyResponseId),
    SurveyQuestionId  INT NOT NULL REFERENCES dbo.SurveyQuestions(SurveyQuestionId),
    AnswerValue       NVARCHAR(MAX) NULL
);
GO

-- A question cannot be hard-deleted once it is in use; this trigger is the
-- T-SQL analogue of the "cannot delete a question assigned to a survey"
-- business rule enforced in SurveyService.SoftDeleteQuestionAsync.
CREATE TRIGGER trg_SurveyQuestions_PreventDeleteInUse
ON dbo.SurveyQuestions
INSTEAD OF DELETE
AS
BEGIN
    SET NOCOUNT ON;
    IF EXISTS (
        SELECT 1 FROM deleted d
        JOIN dbo.SurveyAnswers a ON a.SurveyQuestionId = d.SurveyQuestionId
    )
    BEGIN
        RAISERROR('Cannot hard-delete a question that has responses. Use the Deleted flag instead.', 16, 1);
        ROLLBACK TRANSACTION;
        RETURN;
    END
    DELETE FROM dbo.SurveyQuestions WHERE SurveyQuestionId IN (SELECT SurveyQuestionId FROM deleted);
END
GO

-- Example stored procedure: upsert a response using a dynamic, grouped JSON
-- payload — the T-SQL counterpart of ResponseService's JSON-based answer
-- grouping described in the README.
CREATE PROCEDURE dbo.usp_SubmitSurveyResponse
    @SurveyId INT,
    @Email NVARCHAR(256) = NULL,
    @AnswersJson NVARCHAR(MAX)   -- e.g. [{"QuestionId":5,"Value":"Yes"}, ...]
AS
BEGIN
    SET NOCOUNT ON;
    BEGIN TRANSACTION;

    INSERT INTO dbo.SurveyResponses (SurveyId, Email)
    VALUES (@SurveyId, @Email);

    DECLARE @ResponseId INT = SCOPE_IDENTITY();

    INSERT INTO dbo.SurveyAnswers (SurveyResponseId, SurveyQuestionId, AnswerValue)
    SELECT @ResponseId, QuestionId, Value
    FROM OPENJSON(@AnswersJson)
    WITH (
        QuestionId INT   '$.QuestionId',
        Value      NVARCHAR(MAX) '$.Value'
    );

    COMMIT TRANSACTION;
END
GO
