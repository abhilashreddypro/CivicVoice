USE CivicVoice;
GO

INSERT INTO dbo.Surveys (Name, PublicToken, IntroParagraph, IsPublished, CreateUser)
VALUES
('Community Broadband Access Survey', 'a1b2c3d4e5f6a7b8',
 'This short survey helps the city understand broadband access across neighborhoods. It takes about 5 minutes and your responses are confidential.',
 1, 'seed-script'),
('Public Transit Satisfaction Survey', '9f8e7d6c5b4a3210', NULL, 0, 'seed-script');
GO

DECLARE @SurveyId INT = (SELECT SurveyId FROM dbo.Surveys WHERE PublicToken = 'a1b2c3d4e5f6a7b8');

INSERT INTO dbo.SurveyQuestions (SurveyId, QuestionText, DisplayTypeId, SortOrder, IsRequired, OptionsJson, CreateUser)
VALUES
(@SurveyId, 'Household internet access', 12, 1, 0, NULL, 'seed-script'),           -- SectionHeading
(@SurveyId, 'Do you currently have home internet service?', 4, 2, 1, NULL, 'seed-script'), -- YesNo
(@SurveyId, 'How would you rate your current internet reliability?', 7, 3, 1, NULL, 'seed-script'), -- Likert 1-5
(@SurveyId, 'What is your primary internet provider?', 6, 4, 0,
    '["Provider A","Provider B","Provider C","Other"]', 'seed-script'),            -- RadioButton
(@SurveyId, 'What percentage of your household work/school happens online?', 11, 5, 0, NULL, 'seed-script'); -- PercentEntry
GO
