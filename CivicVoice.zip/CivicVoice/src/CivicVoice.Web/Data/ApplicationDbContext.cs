using CivicVoice.Web.Models;
using Microsoft.EntityFrameworkCore;

namespace CivicVoice.Web.Data;

public class ApplicationDbContext : DbContext
{
    public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options) { }

    public DbSet<Survey> Surveys => Set<Survey>();
    public DbSet<SurveyQuestion> SurveyQuestions => Set<SurveyQuestion>();
    public DbSet<SurveyResponse> SurveyResponses => Set<SurveyResponse>();
    public DbSet<SurveyAnswer> SurveyAnswers => Set<SurveyAnswer>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Survey>(e =>
        {
            e.HasIndex(s => s.PublicToken).IsUnique();
            e.HasMany(s => s.Questions)
             .WithOne(q => q.Survey)
             .HasForeignKey(q => q.SurveyId);
        });

        // Soft-delete filter: deleted questions never surface in normal
        // queries (admin grid, public form, or the Build-Survey autocomplete).
        modelBuilder.Entity<SurveyQuestion>()
            .HasQueryFilter(q => !q.Deleted);

        modelBuilder.Entity<SurveyAnswer>()
            .HasOne<SurveyResponse>()
            .WithMany(r => r.Answers)
            .HasForeignKey(a => a.SurveyResponseId);

        base.OnModelCreating(modelBuilder);
    }
}
