using CivicVoice.Web.Models;

namespace CivicVoice.Web.Services;

public interface IResponseService
{
    Task<(bool Success, List<string> Errors)> SubmitResponseAsync(
        string token, Dictionary<int, string> answers, string? email);
}
