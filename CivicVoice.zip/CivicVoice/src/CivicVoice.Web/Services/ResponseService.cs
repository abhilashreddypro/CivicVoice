using System.Text.RegularExpressions;
using CivicVoice.Web.Data;
using CivicVoice.Web.Models;
using Microsoft.EntityFrameworkCore;

namespace CivicVoice.Web.Services;

public partial class ResponseService : IResponseService
{
    private readonly ApplicationDbContext _db;

    public ResponseService(ApplicationDbContext db) => _db = db;

    [GeneratedRegex(@"^[^@\s]+@[^@\s]+\.[^@\s]+$")]
    private static partial Regex EmailPattern();

    /// <summary>
    /// Server-side validation of a public submission. Never trusts the
    /// browser: re-validates email format, percent (1-100) and
    /// 1-10 scale ranges even though the client already enforced them.
    /// </summary>
    public async Task<(bool Success, List<string> Errors)> SubmitResponseAsync(
        string token, Dictionary<int, string> answers, string? email)
    {
        var errors = new List<string>();

        var survey = await _db.Surveys
            .Include(s => s.Questions)
            .FirstOrDefaultAsync(s => s.PublicToken == token && s.IsPublished);

        if (survey is null)
        {
            errors.Add("This survey link is no longer valid.");
            return (false, errors);
        }

        if (!string.IsNullOrWhiteSpace(email) && !EmailPattern().IsMatch(email))
            errors.Add("Please enter a valid email address.");

        foreach (var q in survey.Questions)
        {
            answers.TryGetValue(q.SurveyQuestionId, out var value);

            if (q.IsRequired && string.IsNullOrWhiteSpace(value) &&
                q.DisplayType is not (QuestionType.SectionHeading or QuestionType.Label))
            {
                errors.Add($"\"{q.QuestionText}\" is required.");
                continue;
            }

            if (string.IsNullOrWhiteSpace(value)) continue;

            switch (q.DisplayType)
            {
                case QuestionType.PercentEntry when !IsInRange(value, 1, 100):
                    errors.Add($"\"{q.QuestionText}\" must be a number between 1 and 100.");
                    break;
                case QuestionType.Rating when !IsInRange(value, 1, 10):
                    errors.Add($"\"{q.QuestionText}\" must be a number between 1 and 10.");
                    break;
            }
        }

        if (errors.Count > 0) return (false, errors);

        var response = new SurveyResponse
        {
            SurveyId = survey.SurveyId,
            Email = email,
            Answers = answers.Select(a => new SurveyAnswer
            {
                SurveyQuestionId = a.Key,
                AnswerValue = a.Value
            }).ToList()
        };

        _db.SurveyResponses.Add(response);
        await _db.SaveChangesAsync();
        return (true, errors);
    }

    private static bool IsInRange(string value, int min, int max) =>
        int.TryParse(value, out var n) && n >= min && n <= max;
}
