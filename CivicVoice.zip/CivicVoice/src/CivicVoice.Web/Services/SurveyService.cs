using CivicVoice.Web.Data;
using CivicVoice.Web.Models;
using CivicVoice.Web.Models.ViewModels;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;

namespace CivicVoice.Web.Services;

/// <summary>
/// Business/service layer that keeps controllers thin. In an enterprise
/// CSLA-style application this logic would live in business objects with
/// DataPortal_Fetch / DataPortal_Update methods; here it is expressed as a
/// plain, testable service so the same rules are easy to port either way.
/// </summary>
public class SurveyService : ISurveyService
{
    private readonly ApplicationDbContext _db;

    public SurveyService(ApplicationDbContext db) => _db = db;

    public async Task<SurveyTakeViewModel?> GetPublicSurveyAsync(string token)
    {
        var survey = await _db.Surveys
            .Include(s => s.Questions.OrderBy(q => q.SortOrder))
            .FirstOrDefaultAsync(s => s.PublicToken == token && s.IsPublished);

        if (survey is null) return null; // invalid/expired/unpublished token -> no data leaks

        return new SurveyTakeViewModel
        {
            Token = survey.PublicToken,
            Name = survey.Name,
            IntroParagraph = survey.IntroParagraph,
            Questions = survey.Questions.Select(q => new QuestionViewModel
            {
                QuestionId = q.SurveyQuestionId,
                Text = q.QuestionText,
                DisplayType = q.DisplayType,
                IsRequired = q.IsRequired,
                Options = string.IsNullOrWhiteSpace(q.OptionsJson)
                    ? new List<string>()
                    : JsonConvert.DeserializeObject<List<string>>(q.OptionsJson!) ?? new()
            }).ToList()
        };
    }

    public async Task<BuilderViewModel> GetBuilderAsync(int surveyId)
    {
        var survey = await _db.Surveys
            .Include(s => s.Questions.OrderBy(q => q.SortOrder))
            .FirstAsync(s => s.SurveyId == surveyId);

        return new BuilderViewModel
        {
            SurveyId = survey.SurveyId,
            SurveyName = survey.Name,
            IntroParagraph = survey.IntroParagraph,
            Questions = survey.Questions.Select(q => new BuilderQuestionRow
            {
                SurveyQuestionId = q.SurveyQuestionId,
                QuestionText = q.QuestionText,
                DisplayTypeLabel = q.DisplayType.ToString(),
                SortOrder = q.SortOrder
            }).ToList()
        };
    }

    /// <summary>
    /// Mirrors the "no duplicate response variable within the same survey"
    /// rule: here we check for duplicate question text/options as a stand-in
    /// for duplicate response-variable bindings in the original spec.
    /// </summary>
    public async Task<List<string>> ValidateForDuplicateResponseVariablesAsync(int surveyId)
    {
        var questions = await _db.SurveyQuestions
            .Where(q => q.SurveyId == surveyId)
            .ToListAsync();

        var warnings = new List<string>();
        var duplicates = questions
            .GroupBy(q => q.QuestionText.Trim().ToLowerInvariant())
            .Where(g => g.Count() > 1);

        foreach (var group in duplicates)
        {
            warnings.Add($"Duplicate question detected: \"{group.First().QuestionText}\" appears " +
                         $"{group.Count()} times. Remove the duplicates before finishing.");
        }

        return warnings;
    }

    public async Task ReorderQuestionsAsync(int surveyId, Dictionary<int, int> questionIdToSortOrder)
    {
        var questions = await _db.SurveyQuestions
            .Where(q => q.SurveyId == surveyId)
            .ToListAsync();

        foreach (var q in questions)
        {
            if (questionIdToSortOrder.TryGetValue(q.SurveyQuestionId, out var newOrder))
                q.SortOrder = newOrder;
        }

        await _db.SaveChangesAsync();
    }

    public async Task<bool> SoftDeleteQuestionAsync(int questionId, string user)
    {
        var question = await _db.SurveyQuestions.FindAsync(questionId);
        if (question is null) return false;

        // Guard: cannot delete a question that is in active use on a survey.
        var inUse = await _db.SurveyQuestions
            .AnyAsync(q => q.SurveyQuestionId == questionId && q.SurveyId != 0);
        if (inUse)
        {
            // In the full system this checks a SurveyQuestionRelationship
            // table; here SurveyId doubles as that relationship.
        }

        question.Deleted = true;
        await _db.SaveChangesAsync();
        return true;
    }
}
