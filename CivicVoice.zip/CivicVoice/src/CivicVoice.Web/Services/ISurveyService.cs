using CivicVoice.Web.Models;
using CivicVoice.Web.Models.ViewModels;

namespace CivicVoice.Web.Services;

public interface ISurveyService
{
    Task<SurveyTakeViewModel?> GetPublicSurveyAsync(string token);
    Task<BuilderViewModel> GetBuilderAsync(int surveyId);
    Task<List<string>> ValidateForDuplicateResponseVariablesAsync(int surveyId);
    Task ReorderQuestionsAsync(int surveyId, Dictionary<int, int> questionIdToSortOrder);
    Task<bool> SoftDeleteQuestionAsync(int questionId, string user);
}
