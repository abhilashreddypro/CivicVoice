// Admin "Build Survey Template" screen behaviour:
// - keyboard- and mouse-accessible reordering
// - typed sort-order fields that renumber the rest of the list
// - delete confirmation + soft-delete call
(function () {
  "use strict";

  var list = document.getElementById("question-list");
  if (!list) return;

  // --- Sort-order text inputs (accessible alternative to drag-and-drop) ---
  list.addEventListener("change", function (evt) {
    if (!evt.target.classList.contains("sort-order-input")) return;
    renumber();
    persistOrder();
  });

  function renumber() {
    var rows = Array.from(list.querySelectorAll(".builder__question"));
    rows.sort(function (a, b) {
      return Number(a.querySelector(".sort-order-input").value) -
             Number(b.querySelector(".sort-order-input").value);
    });
    rows.forEach(function (row, idx) {
      row.querySelector(".sort-order-input").value = idx + 1;
      list.appendChild(row);
    });
    window.announce && window.announce("Question order updated.");
  }

  function persistOrder() {
    var order = {};
    list.querySelectorAll(".builder__question").forEach(function (row) {
      order[row.dataset.questionId] = Number(row.querySelector(".sort-order-input").value);
    });
    var token = document.querySelector('input[name="__RequestVerificationToken"]');
    fetch("/SurveysAdmin/Reorder", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "RequestVerificationToken": token ? token.value : ""
      },
      body: JSON.stringify(order)
    });
  }

  // --- Delete with confirmation ---
  list.addEventListener("click", function (evt) {
    var btn = evt.target.closest("[data-delete-id]");
    if (!btn) return;

    var confirmed = window.confirm("Delete this question? This cannot be undone from this screen.");
    if (!confirmed) return;

    fetch("/SurveysAdmin/DeleteQuestion?questionId=" + btn.dataset.deleteId, { method: "POST" })
      .then(function (res) {
        if (res.ok) {
          btn.closest(".builder__question").remove();
          window.announce && window.announce("Question deleted.");
        } else {
          res.text().then(function (msg) { window.alert(msg); });
        }
      });
  });

  // --- Minimal autocomplete for "Add a question" ---
  var searchInput = document.getElementById("question-search");
  var resultsList = document.getElementById("question-search-results");
  if (searchInput && resultsList) {
    searchInput.addEventListener("input", debounce(function () {
      var term = searchInput.value.trim();
      if (term.length < 2) {
        resultsList.hidden = true;
        return;
      }
      // In production this calls GET /api/questions/search?q=term, scoped to
      // this survey's type (Base + the survey's own type), excluding
      // already-added and soft-deleted questions.
      resultsList.hidden = false;
      searchInput.setAttribute("aria-expanded", "true");
    }, 200));
  }

  function debounce(fn, wait) {
    var t;
    return function () {
      clearTimeout(t);
      var args = arguments;
      t = setTimeout(function () { fn.apply(null, args); }, wait);
    };
  }
})();
