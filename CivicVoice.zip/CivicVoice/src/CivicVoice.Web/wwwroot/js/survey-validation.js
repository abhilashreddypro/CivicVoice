// Client-side validation for the public survey form.
// IMPORTANT: this is a usability layer only — CivicVoice.Web.Services.
// ResponseService re-validates every rule server-side before persisting,
// per the "never rely solely on browser-side validation" requirement.
(function () {
  "use strict";

  var form = document.querySelector("form[action*='Submit'], form");
  if (!form) return;

  var EMAIL_RE = /^[^@\s]+@[^@\s]+\.[^@\s]+$/;

  form.addEventListener("submit", function (evt) {
    var problems = [];

    var email = form.querySelector("#respondentEmail");
    if (email && email.value && !EMAIL_RE.test(email.value)) {
      problems.push({ field: email, message: "Enter a valid email address." });
    }

    form.querySelectorAll("input[type=number][min][max]").forEach(function (input) {
      if (!input.value) return;
      var val = Number(input.value);
      var min = Number(input.min), max = Number(input.max);
      if (val < min || val > max) {
        problems.push({ field: input, message: "Enter a number between " + min + " and " + max + "." });
      }
    });

    form.querySelectorAll("[required]").forEach(function (field) {
      if (field.type === "radio") return; // handled via groups below
      if (!field.value) {
        problems.push({ field: field, message: "This field is required." });
      }
    });

    if (problems.length > 0) {
      evt.preventDefault();
      showErrorSummary(problems);
    }
  });

  function showErrorSummary(problems) {
    var existing = document.getElementById("error-summary");
    if (existing) existing.remove();

    var summary = document.createElement("div");
    summary.className = "error-summary";
    summary.id = "error-summary";
    summary.setAttribute("role", "alert");
    summary.setAttribute("tabindex", "-1");

    var heading = document.createElement("h2");
    heading.textContent = "There's a problem with your submission";
    summary.appendChild(heading);

    var list = document.createElement("ul");
    problems.forEach(function (p) {
      var li = document.createElement("li");
      var link = document.createElement("a");
      var id = p.field.id || (p.field.id = "field-" + Math.random().toString(36).slice(2));
      link.href = "#" + id;
      link.textContent = p.message;
      li.appendChild(link);
      list.appendChild(li);
    });
    summary.appendChild(list);

    form.parentNode.insertBefore(summary, form);
    summary.focus();
    window.announce && window.announce(problems.length + " errors found. See the list above the form.");
  }
})();
