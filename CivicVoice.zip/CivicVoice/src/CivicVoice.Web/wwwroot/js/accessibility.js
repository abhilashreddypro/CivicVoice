// Shared accessibility helpers used across the site.
(function () {
  "use strict";

  var liveRegion = document.getElementById("live-region");

  /** Announce a message to assistive tech via the page's polite live region. */
  window.announce = function (message) {
    if (!liveRegion) return;
    liveRegion.textContent = "";
    // Reset then set on next tick so repeated identical messages still fire.
    window.setTimeout(function () {
      liveRegion.textContent = message;
    }, 50);
  };

  // On load, if an error summary is present, move focus to it so screen
  // reader / keyboard users land directly on the problem (WCAG 3.3.1).
  document.addEventListener("DOMContentLoaded", function () {
    var summary = document.getElementById("error-summary");
    if (summary) {
      summary.focus();
    }
  });
})();
