using CivicVoice.Web.Services;
using Microsoft.AspNetCore.Mvc;

namespace CivicVoice.Web.Controllers;

// In production this carries [Authorize(Roles = "SurveyAdmin")] backed by
// Azure AD / enterprise SSO. Omitted here so the sample runs standalone.
public class SurveysAdminController : Controller
{
    private readonly ISurveyService _surveys;

    public SurveysAdminController(ISurveyService surveys) => _surveys = surveys;

    public IActionResult Index() => View();

    public async Task<IActionResult> Builder(int id)
    {
        var model = await _surveys.GetBuilderAsync(id);
        model.ValidationWarnings = await _surveys.ValidateForDuplicateResponseVariablesAsync(id);
        return View(model);
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Reorder(int surveyId, [FromBody] Dictionary<int, int> order)
    {
        await _surveys.ReorderQuestionsAsync(surveyId, order);
        return Ok();
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> DeleteQuestion(int questionId)
    {
        var ok = await _surveys.SoftDeleteQuestionAsync(questionId, User.Identity?.Name ?? "system");
        return ok ? Ok() : BadRequest("Question is in use on a survey and cannot be deleted.");
    }
}
