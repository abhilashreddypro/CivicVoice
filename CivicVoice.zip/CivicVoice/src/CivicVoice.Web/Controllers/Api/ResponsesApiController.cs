using CivicVoice.Web.Data;
using CivicVoice.Web.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace CivicVoice.Web.Controllers.Api;

/// <summary>
/// REST API consumed by middleware / downstream reporting systems.
/// Read-only, authenticated in production, and never returns raw
/// respondent-identifying data without explicit scoping.
/// </summary>
[ApiController]
[Route("api/[controller]")]
public class ResponsesApiController : ControllerBase
{
    private readonly ApplicationDbContext _db;
    public ResponsesApiController(ApplicationDbContext db) => _db = db;

    /// <summary>GET /api/responses/summary/{surveyId} — aggregate counts only, no PII.</summary>
    [HttpGet("summary/{surveyId:int}")]
    public async Task<IActionResult> Summary(int surveyId)
    {
        var count = await _db.SurveyResponses.CountAsync(r => r.SurveyId == surveyId);
        return Ok(new { surveyId, responseCount = count });
    }
}
