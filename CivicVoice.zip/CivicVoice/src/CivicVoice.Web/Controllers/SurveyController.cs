using CivicVoice.Web.Services;
using Microsoft.AspNetCore.Mvc;

namespace CivicVoice.Web.Controllers;

/// <summary>
/// PUBLIC, unauthenticated surface. Only ever returns the flat
/// SurveyTakeViewModel projection — never the EF entity — so no internal
/// identifiers, audit columns, or other-survey data can leak to a
/// respondent's browser.
/// </summary>
public class SurveyController : Controller
{
    private readonly ISurveyService _surveys;
    private readonly IResponseService _responses;

    public SurveyController(ISurveyService surveys, IResponseService responses)
    {
        _surveys = surveys;
        _responses = responses;
    }

    [HttpGet]
    public async Task<IActionResult> Take(string token)
    {
        var survey = await _surveys.GetPublicSurveyAsync(token);
        if (survey is null) return View("InvalidLink"); // no survey data rendered
        return View(survey);
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Submit(string token, [FromForm] Dictionary<int, string> answers, string? email)
    {
        var (success, errors) = await _responses.SubmitResponseAsync(token, answers, email);

        if (!success)
        {
            TempData["SubmitErrors"] = string.Join("|", errors);
            return RedirectToAction(nameof(Take), new { token });
        }

        return RedirectToAction(nameof(Confirmation));
    }

    public IActionResult Confirmation() => View();
}
