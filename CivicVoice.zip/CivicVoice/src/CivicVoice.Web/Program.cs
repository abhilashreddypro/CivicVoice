using CivicVoice.Web.Data;
using CivicVoice.Web.Services;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

// --- Services ----------------------------------------------------------
builder.Services.AddControllersWithViews();

builder.Services.AddDbContext<ApplicationDbContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("CivicVoiceDb")));

// Business/service layer (keeps controllers thin, mirrors a CSLA-style
// separation between presentation and business logic).
builder.Services.AddScoped<ISurveyService, SurveyService>();
builder.Services.AddScoped<IResponseService, ResponseService>();

builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(c =>
{
    c.SwaggerDoc("v1", new() { Title = "CivicVoice API", Version = "v1" });
});

// Response compression + caching keep the public survey fast on
// low-bandwidth / mobile connections, which matters for accessibility.
builder.Services.AddResponseCompression();

var app = builder.Build();

// --- Middleware pipeline -------------------------------------------------
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}
else
{
    app.UseSwagger();
    app.UseSwaggerUI(c => c.SwaggerEndpoint("/swagger/v1/swagger.json", "CivicVoice API v1"));
}

app.UseHttpsRedirection();
app.UseStaticFiles();
app.UseResponseCompression();

app.UseRouting();
app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

// Public, token-based survey link — e.g. /s/{publicToken} — deliberately
// does NOT expose the internal SurveyId, mirroring the "no sequential ID"
// requirement from the original survey-publishing spec.
app.MapControllerRoute(
    name: "publicSurvey",
    pattern: "s/{token}",
    defaults: new { controller = "Survey", action = "Take" });

app.MapControllers(); // attribute-routed Web API controllers under /api

app.Run();
