namespace CivicVoice.Web.Models.ViewModels;

/// <summary>
/// Flat, UI-friendly projection of a Survey used by the public-facing,
/// accessible form. Keeping this separate from the EF entity means the
/// public site never serializes internal fields (SurveyId, CreateUser,
/// Deleted flags, etc.) back to the browser.
/// </summary>
public class SurveyTakeViewModel
{
    public string Token { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
    public string? IntroParagraph { get; set; }
    public List<QuestionViewModel> Questions { get; set; } = new();
}

public class QuestionViewModel
{
    public int QuestionId { get; set; }
    public string Text { get; set; } = string.Empty;
    public QuestionType DisplayType { get; set; }
    public bool IsRequired { get; set; }
    public List<string> Options { get; set; } = new();
}
