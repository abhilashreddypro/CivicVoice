namespace CivicVoice.Web.Models.ViewModels;

/// <summary>Backs the admin "Survey Builder" screen (drag/drop ordering,
/// add/remove questions, duplicate-response-variable warnings).</summary>
public class BuilderViewModel
{
    public int SurveyId { get; set; }
    public string SurveyName { get; set; } = string.Empty;
    public string? IntroParagraph { get; set; }
    public List<BuilderQuestionRow> Questions { get; set; } = new();
    public List<string> ValidationWarnings { get; set; } = new();
}

public class BuilderQuestionRow
{
    public int SurveyQuestionId { get; set; }
    public string QuestionText { get; set; } = string.Empty;
    public string DisplayTypeLabel { get; set; } = string.Empty;
    public int SortOrder { get; set; }
}
