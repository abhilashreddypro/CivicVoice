using System.ComponentModel.DataAnnotations;

namespace CivicVoice.Web.Models;

/// <summary>Top-level survey definition.</summary>
public class Survey
{
    public int SurveyId { get; set; }

    [Required, StringLength(200)]
    public string Name { get; set; } = string.Empty;

    /// <summary>
    /// Opaque, unguessable token used in the public URL (/s/{PublicToken}) so
    /// respondents can never enumerate other surveys by walking SurveyId.
    /// </summary>
    [Required, StringLength(32)]
    public string PublicToken { get; set; } = Guid.NewGuid().ToString("N")[..16];

    public string? IntroParagraph { get; set; }

    public bool IsPublished { get; set; }

    public DateTime CreateDt { get; set; } = DateTime.UtcNow;
    public string CreateUser { get; set; } = string.Empty;
    public DateTime? UpdateDt { get; set; }
    public string? UpdateUser { get; set; }

    public List<SurveyQuestion> Questions { get; set; } = new();
}
