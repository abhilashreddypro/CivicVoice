namespace CivicVoice.Web.Models;

/// <summary>
/// Mirrors a "DisplayType" lookup table in the database (QuestionTypes table).
/// Each value drives both the server-rendered SurveyQuestion editor behaviour
/// (required/disabled fields) and the dynamic control generated on the
/// public-facing form.
/// </summary>
public enum QuestionType
{
    ShortText = 1,
    LongText = 2,
    Dropdown = 3,
    YesNo = 4,
    Checkbox = 5,
    RadioButton = 6,
    LikertFivePoint = 7,
    LikertWithNotSure = 8,
    Rating = 9,
    NumericEntry = 10,
    PercentEntry = 11,
    SectionHeading = 12,
    Label = 13
}
