using System.ComponentModel.DataAnnotations;

namespace CivicVoice.Web.Models;

public class SurveyQuestion
{
    public int SurveyQuestionId { get; set; }
    public int SurveyId { get; set; }
    public Survey? Survey { get; set; }

    [Required, StringLength(1000)]
    public string QuestionText { get; set; } = string.Empty;

    public QuestionType DisplayType { get; set; }

    public int SortOrder { get; set; }

    public bool IsRequired { get; set; } = true;

    /// <summary>JSON-encoded list of options for Dropdown / RadioButton / Checkbox types.</summary>
    public string? OptionsJson { get; set; }

    public bool Deleted { get; set; }

    // --- Validation rules enforced server-side (see SurveyQuestionValidator) ---
    // RadioButton / Dropdown  -> OptionsJson required
    // PercentEntry            -> answer restricted 1-100
    // Rating (1-10 scale)     -> answer restricted 1-10
    // Label / SectionHeading  -> no response variable, never required
}
