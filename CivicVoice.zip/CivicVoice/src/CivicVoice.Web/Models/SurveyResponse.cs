namespace CivicVoice.Web.Models;

/// <summary>One respondent's full submission for a survey.</summary>
public class SurveyResponse
{
    public int SurveyResponseId { get; set; }
    public int SurveyId { get; set; }

    public DateTime SubmittedDt { get; set; } = DateTime.UtcNow;

    /// <summary>Optional respondent-supplied contact email, format-validated client + server side.</summary>
    public string? Email { get; set; }

    public List<SurveyAnswer> Answers { get; set; } = new();
}

public class SurveyAnswer
{
    public int SurveyAnswerId { get; set; }
    public int SurveyResponseId { get; set; }
    public int SurveyQuestionId { get; set; }

    /// <summary>Stores the answer as text; numeric/range validation happens before persistence.</summary>
    public string? AnswerValue { get; set; }
}
